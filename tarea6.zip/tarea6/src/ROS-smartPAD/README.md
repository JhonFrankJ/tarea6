# ROS SmartPAD v3
Tutorial: </br>
https://youtu.be/6XYw795jLpA
